import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Bank } from './Bank';

@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.css']
})
export class BankComponent implements OnInit {
 bank: Bank= new Bank();
  constructor(private service:BankService) { }

  ngOnInit(): void {
  }
  public bankDetail(){
    let resp = this.service.bankdetail(this.bank);
    resp.subscribe((data)=>data);
  }

}
