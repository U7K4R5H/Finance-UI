export class Bank{
    bankType :  string|undefined;
    ifscCode :  string|undefined;  
}