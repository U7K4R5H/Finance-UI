import { Component, OnInit } from '@angular/core';
import { Card } from '../card';
import { CardService } from '../card.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  mycard: Card = new Card();

  constructor(private cardservice: CardService) { }

  ngOnInit(): void {
    this.getCardDetail();
  }
  private getCardDetail() {
    this.cardservice.getCardByUser(987654321).subscribe(data =>{
      this.mycard = data;
    })
  }
}
